//
//  WZYSocketManager.swift
//  WZYSocketManager
//
//  Created by SD.Man on 2021/3/12.
//

import Foundation
import CocoaAsyncSocket

let serverPort: UInt16 = 1235
var host = "192.168.1.133"

class WZYSocketClientManager: NSObject {
    
    var asyncSocket: GCDAsyncSocket?
    var receive: String = ""
    // 显示在TextView的消息日志
    var messages: [String] = [String]()
    
    // 创建单例
    static let shared = WZYSocketClientManager()
    // 加入了一个私有的初始化方法，让项目中的其他地方不能够通过 init 来生成自己的 MyManager 实例
    private override init() {
        super.init()
        initSocket()
    }
    
    // 初始化Socket接口
    private func initSocket() {
        
        /*
           If you choose to provide a socket queue, the socket queue must not be a concurrent queue
           第二个参数不能是一个并发队列
        */
        // 在全局串行队列运行
        asyncSocket = GCDAsyncSocket(delegate: self, delegateQueue: DispatchQueue.global(qos: .default))
        
    }
    
    // MARK: - 对外接口
    
    // 判断连接状态
    func connect() -> Bool {
        
        var connectStatus: Bool = false
        
        do {
            connectStatus = ((try asyncSocket?.connect(toHost: host, onPort: serverPort)) != nil)
        } catch {
            print(error)
        }
        
        return connectStatus
    }
    
    // 断开连接
    func disConnect() {
        asyncSocket?.disconnect()
    }
    
    // 发送消息--tag与read相同
    func sendMessage(message: String) {
        // If the timeout value is negative, the write operation will not use a timeout.
        // timeout为负数则不考虑超时
        asyncSocket?.write(message.data(using: .utf8), withTimeout: -1, tag: 111)
    }
    
    // 监听最新消息--tag与write相同
    func pullMessage() {
        // timeout为负数则不考虑超时
        // 但只监听一次，需要多次调用
        asyncSocket?.readData(withTimeout: -1, tag: 111)
    }
    
}

//MARK: - socket连接过程的回调函数

extension WZYSocketClientManager: GCDAsyncSocketDelegate {
    
    // Connect之后的回调函数
    func socket(_ sock: GCDAsyncSocket, didConnectToHost host: String, port: UInt16) {
        print("连接成功, host: \(String(describing: sock.localHost)), port: \(sock.localPort)")
    }
    
    /*
       Called when a socket has completed reading the requested data into memory
       Socket读取完全部请求获得的数据到内存之后调用该回调函数
     
       服务端最好不要用纯文本发送？双向encode方式要一致？
    */
    func socket(_ sock: GCDAsyncSocket, didRead data: Data, withTag tag: Int) {
        print("Client读取Tag\(tag)完成")
        
        // 用于给主vc显示接收到的消息
        let str = String(data: data, encoding: String.Encoding.utf8)
        receive = str ?? "解析错误"
        // 乱码与encoding方式有关，若编码解码都用的utf8就不会出现中文英文乱码
        print(receive)
        
        guard let host = sock.connectedHost else { return }
        
        // 写入消息数组
        let message =
        """

        时间:\(currentTime())
        主机:\(host):\(sock.connectedPort)
        收到消息:\(receive)

        """
        messages.append(message)
    }
    
    /*
       Called when a socket has completed writing the requested data. Not called if there is an error
       socket写入全部数据之后调用，如果出现错误则不调用
     */
    func socket(_ sock: GCDAsyncSocket, didWriteDataWithTag tag: Int) {
        print("Client写入Tag\(tag)完成")
    }
    
    /*
       Called when a socket disconnects with or without error
       socket断开连接后调用，无论是否因为error而引起的
       
       如果GCDAsyncSocket实例在它仍然连接的时候被释放，委托也没有被释放，那么这个方法会被调用，
       但sock参数将为nil。因为它不再可用。
    */
    func socketDidDisconnect(_ sock: GCDAsyncSocket, withError err: Error?) {
        if let error = err {
            print("出现错误\(error)，断开连接")
        } else {
            print("未出现错误，主动断开连接")
        }
    }
    
}

extension WZYSocketClientManager {
    func currentTime() -> String {
        let dateformatter = DateFormatter()
        // 自定义时间格式
        dateformatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
        // GMT时间 转字符串，直接是系统当前时间
        return dateformatter.string(from: Date())
    }
}
