//
//  ViewController.swift
//  WZYSocketClientManager
//
//  Created by SD.Man on 2021/3/13.
//

import UIKit
import CocoaAsyncSocket

class ViewController: UIViewController {

    @IBOutlet weak var sendTextField: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    var timer: Timer?
    
    // 用于判断shared.logs.count日志数目是否有更新
    var count = 0
    // 用于替换textView内容
    var text = ""
    
    // 获取单例
    let shared = WZYSocketClientManager.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
    }

    @IBAction func sendAction(_ sender: Any) {
        if let message = sendTextField.text, message.count != 0 {
            shared.sendMessage(message: message)
            // 清空输入框
            sendTextField.text = ""
        } else {
            print("不能发送空消息")
        }
    }
    
    @IBAction func linkAction(_ sender: Any) {
        if shared.connect() {
            shared.sendMessage(message: "Hello Server!")
            // 主线程创建一个并发队列用于每隔半秒接受一次消息
            timerReceive()
        }
    }
    
    @IBAction func breakLinkAction(_ sender: Any) {
        shared.disConnect()
        // 关闭用于定时接收消息的计时器
        timer?.invalidate()
        // 清空输入框
        cleanAfterBreakLink()
    }
    
    func updateTextView() {
        if count != shared.messages.count {
            count = shared.messages.count
            for index in 0..<shared.messages.count {
                // 每次都生成完整的日志，用于直接替换textview文字
                text.append(shared.messages[index])
                textView.text = text
            }
            text = ""
        }
    }
    
    func timerReceive() {
        print("timerReceive")
        // 创建一个并发队列
        let queue = DispatchQueue(label: "tech.sdman.queue", qos: .default, attributes: .concurrent)
        
        // 每1秒开始并发执行一次接收消息任务
        timer = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true, block: { (timer) in
            // 定时器是调用scheduledTimer方法，不是init方法，坑！
            
            // 主线程 + 并发队列 + 异步 = 开启新线程并发执行任务
            queue.async {
                self.shared.pullMessage()
            }
            
            // 栅栏方法，等消息接收完再进行显示，避免显示空消息
            queue.async(group: nil, qos: .default, flags: .barrier) {
                print("消息接收完成……继续探测……")
            }
            
            // 组件必须在主线程使用，所以放在栅栏方法后避免接收消息提前导致错误
            DispatchQueue.main.async {
                self.updateTextView()
            }
        })
        
        // 计时器默认自动启动
        
    }
    
    // 清空输入栏
    func cleanAfterBreakLink() {
        sendTextField.text = ""
    }
    
}

extension ViewController {
    //隐藏键盘
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
}

