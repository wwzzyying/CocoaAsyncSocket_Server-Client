//
//  WZYSocketServerManager.swift
//  WZYSocketServerManager
//
//  Created by SD.Man on 2021/3/13.
//
// socket-->bind()-->listen()-->accept()
import Foundation
import CocoaAsyncSocket

let serverPort: UInt16 = 1235

class WZYSocketServerManager: NSObject {
    
    var serverSocket: GCDAsyncSocket?
    // 把数据写向客户端，所有读写的回调函数都要使用clientSocket，在服务端accept成功后初始化
    // 或者可以变为数组类型，保存多个连接，现在的缺陷就是只能处理一个客户端连接
    var clientSocket: GCDAsyncSocket?
    
    // 接收到的消息
    var receive = ""
    
    // 显示在TextView的log日志
    var logs: [String] = [String]()
    
    // 创建单例
    static let shared = WZYSocketServerManager()
    // 加入了一个私有的初始化方法，让项目中的其他地方不能够通过 init 来生成自己的 MyManager 实例
    private override init() {
        super.init()
        initSocket()
    }
    
    // 初始化Socket接口
    private func initSocket() {
        
        /*
           If you choose to provide a socket queue, the socket queue must not be a concurrent queue
           第二个参数不能是一个并发队列
        */
        // 在全局串行队列运行
        serverSocket = GCDAsyncSocket(delegate: self, delegateQueue: DispatchQueue.global(qos: .default))
        
    }
    
    // MARK: - 对外接口
    
    // 完成bind、listen和accept
    func accept() -> Bool {
        var acceptStatus: Bool = false
        // Tells the socket to begin listening and accepting connections on the given port
        do {
            acceptStatus = ((try serverSocket?.accept(onPort: serverPort)) != nil)
            logs.append(
            """
            服务端已开启，等待客户端连接

            """
            )
            // 触发didAcceptNewSocket回调函数
        } catch {
            print("貌似连接不上客户端: \(error)")
            logs.append(
            """
            貌似连接不上客户端

            """
            )
        }
        return acceptStatus
    }
    
    // 发送消息--tag与read相同
    func sendMessage(message: String) {
        // If the timeout value is negative, the write operation will not use a timeout.
        // timeout为负数则不考虑超时
        clientSocket?.write(message.data(using: .utf8), withTimeout: -1, tag: 110)
    }
    
    // 监听最新消息--tag与write相同
    func pullMessage() {
        // timeout为负数则不考虑超时
        // 但只监听一次，需要多次调用
        clientSocket?.readData(withTimeout: -1, tag: 110)
    }
    
}

//MARK: - socket连接过程的回调函数

extension WZYSocketServerManager: GCDAsyncSocketDelegate {
    
    /*
       Called when a socket accepts a connection
       当socket接受了一个Client连接时调用该回调函数
       You must retain the newSocket if you wish to handle the connection
       保持这个newSocket的强连接
     */
    func socket(_ sock: GCDAsyncSocket, didAcceptNewSocket newSocket: GCDAsyncSocket) {
        // 保持newSocket强引用
        clientSocket = newSocket
        guard let host = newSocket.localHost else { return }
        // 打印并添加日志信息
        print("成功连接Client: \(host): \(newSocket.localPort)")
        logs.append(
        """

        成功连接Client: \(host): \(newSocket.localPort)

        """
        )
    }
    
    // writeData触发
    func socket(_ sock: GCDAsyncSocket, didWriteDataWithTag tag: Int) {
        print("Server写入Tag\(tag)完成")
    }
    
    // readData触发
    func socket(_ sock: GCDAsyncSocket, didRead data: Data, withTag tag: Int) {
        print("Server读取Tag\(tag)完成")
        
        // 解析数据
        let str = String(data: data, encoding: String.Encoding.utf8)
        receive = str ?? "解析错误"
        print(receive)
        
        guard let host = sock.connectedHost else { return }
        
        // 写入日志数组
        let log =
        """

        时间:\(currentTime())
        主机:\(host):\(sock.connectedPort)
        长度:\(NSData(data: data).length) 结果:\(receive)

        """
        logs.append(log)
    }
    
    func socketDidDisconnect(_ sock: GCDAsyncSocket, withError err: Error?) {
        // 写入日志数组
        let log =
        """

        时间:\(currentTime()) 客户端断开连接

        """
        logs.append(log)
    }
    
}

extension WZYSocketServerManager {
    func currentTime() -> String {
        let dateformatter = DateFormatter()
        // 自定义时间格式
        dateformatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
        // GMT时间 转字符串，直接是系统当前时间
        return dateformatter.string(from: Date())
    }
}
