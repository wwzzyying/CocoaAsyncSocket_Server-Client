//
//  ViewController.swift
//  WZYSocketServerManager
//
//  Created by SD.Man on 2021/3/13.
//

import UIKit
import CocoaAsyncSocket

class ViewController: UIViewController {

    @IBOutlet weak var sendTextField: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    var timer: Timer?
    
    // 用于判断shared.logs.count日志数目是否有更新
    var count = 0
    // 用于替换textView内容
    var text = ""
    
    // 获取单例
    let shared = WZYSocketServerManager.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        updateTextView()
    }

    @IBAction func send(_ sender: Any) {
        if let message = sendTextField.text, message.count != 0 {
            shared.sendMessage(message: message)
            // 清空输入框
            sendTextField.text = ""
        } else {
            print("不能发送空消息")
        }
    }
    
    @IBAction func link(_ sender: Any) {
        if shared.accept() {
            // 建立连接成功之后开始定时接收消息
            timerReceive()
        }
    }
    
    func updateTextView() {
        if count != shared.logs.count {
            count = shared.logs.count
            for index in 0..<shared.logs.count {
                // 每次都生成完整的日志，用于直接替换textview文字
                text.append(shared.logs[index])
                textView.text = text
            }
            text = ""
        }
    }
    
    func timerReceive() {
        // 创建一个并发队列
        let queue = DispatchQueue(label: "tech.sdman.queue2", qos: .default, attributes: .concurrent)
        
        // 每0.5秒开始并发执行一次接收消息任务
        timer = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true, block: { (timer) in
            // 定时器是调用scheduledTimer方法，不是init方法，坑！
            
            // 主线程 + 并发队列 + 异步 = 开启新线程并发执行任务
            queue.async {
                self.shared.pullMessage()
            }
            
            
            // 栅栏方法，等消息接收完再进行显示，避免显示空消息
            queue.async(group: nil, qos: .default, flags: .barrier) {
                
            }
            
            DispatchQueue.main.async {
                self.updateTextView()
            }
        })
        
        // 计时器默认自动启动
        
    }
}

extension ViewController {
    //隐藏键盘
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
}

